package com.sps.scripts;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.reports.CustomReporter;
import com.sps.pages.BaseClass;
import com.sps.pages.Clinical_Info_Page;
import com.sps.pages.Login_Page;
import com.sps.pages.Request_info_Page;
import com.sps.pages.Search_MRN;

public class UpdateRequest extends BaseClass {
	@BeforeTest
	public void propfilereader()
	{
		propertiesFileReader("src/objectrepository/SPS.properties");
	
	}
@Test
public void UpdateRequest() throws InterruptedException{
	
	String UN = property.getProperty("email");	
	String password = property.getProperty("password");
	String MRN = property.getProperty("MRN");
	System.out.println(MRN);
	String Surgeon = property.getProperty("Surgeon");
	//String Requestor = property.getProperty("Requestor");
	CustomReporter.log("Enter valid user id and password");
	Login_Page lp = new Login_Page(driver);
	lp.LoginSPS(UN, password);
	
	
	
	Search_MRN mrn = new Search_MRN(driver);
	
	mrn.SearchMRN(MRN);
	
	
	Request_info_Page ReqInfo = new Request_info_Page(driver);
	String pat = ReqInfo.RequestInfoSPS(Surgeon, driver);
	
	CustomReporter.log("Info : " + pat);
	
	Clinical_Info_Page ClinInfo = new Clinical_Info_Page(driver);
	ClinInfo.ClinicalInfoSPS(driver);
	driver.close();
	
}
	


}