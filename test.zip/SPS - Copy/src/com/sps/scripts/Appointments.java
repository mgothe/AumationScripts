package com.sps.scripts;



import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.reports.CustomReporter;
import com.sps.pages.Appointments_Page;
import com.sps.pages.BaseClass;
import com.sps.pages.Clinical_Info_Page;
import com.sps.pages.Login_Page;
import com.sps.pages.Request_info_Page;
import com.sps.pages.Search_MRN;

import common.Excel;
import common.Reusable_Methods;

public class Appointments extends BaseClass {
	
	Reusable_Methods RM;
	Excel XL;
	@BeforeTest
	public void propfilereader()
	{
		propertiesFileReader("src/objectrepository/SPS.properties");
	
	}

@Test
public void test_use198() throws InterruptedException{
	
	RM= new Reusable_Methods();
	XL = new Excel();
	
	String UN = XL.getCellValue("Appointments", 2, 4);	
	
	String password = XL.getCellValue("Appointments", 2, 5);
	String MRN = XL.getCellValue("Appointments", 2, 6);
	System.out.println(MRN);
	String Surgeon = XL.getCellValue("Appointments", 2, 7);
	//String Requestor = property.getProperty("Requestor");
	CustomReporter.log("Enter valid user id and password");
	Login_Page lp = new Login_Page(driver);
	lp.LoginSPS(UN, password);
	
	
	
	Search_MRN mrn = new Search_MRN(driver);
	
	mrn.SearchMRN(MRN);
	
	
	Request_info_Page ReqInfo = new Request_info_Page(driver);
	String pat = ReqInfo.RequestInfoSPS(Surgeon, driver);
	
	CustomReporter.log("Info : " + pat);
	
	Appointments_Page ApptSPS= new Appointments_Page(driver);
	ApptSPS.AppointmentSPS(driver);
	
	/*Clinical_Info_Page ClinInfo = new Clinical_Info_Page(driver);
	ClinInfo.ClinicalInfoSPS(driver);*/
	driver.close();
	
}
}