package com.sps.scripts;

public class Consults {

}
