package com.sps.scripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

import common.Excel;
import common.Reusable_Methods;

public class Z_SecurityManager {
	
	static Reusable_Methods RM;
	static Excel XL;

	/*public Z_SecurityManager(WebDriver driver)
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		PageFactory.initElements(driver, this);
		
				
	}*/
	
	public static void main(String[] args) throws InterruptedException {
		
		  WebDriver driver = new FirefoxDriver();

		  RM= new Reusable_Methods();
			XL = new Excel();
		  
		  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		  
		  String appUrl = "http://chwebtest.tch.harvard.edu/security_mgr/";
		  driver.get(appUrl);
		  
		  WebElement Username = driver.findElement(By.xpath("id('username')"));
		  
		  Username.click();
		  Username.sendKeys("ch181435");
		  
		  WebElement Pwd = driver.findElement(By.xpath("id('password')"));
		  Pwd.click();
		  Pwd.sendKeys("$RFVvfr4");
		  
		  
		  WebElement btn_Login = driver.findElement(By.xpath("id('fm1')/table/tbody/tr[7]/td[3]/input[3]"));
		  
		  btn_Login.click();
	
		  WebElement link_UserSecAdmin = driver.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[2]/table/tbody/tr/td/table/tbody/tr[2]/td[2]/a"));
		  link_UserSecAdmin.click();
		  
		  WebElement txt_EmpNumb = driver.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[2]/table/tbody/tr/td/form/table/tbody/tr[3]/td[2]/input"));
		  
		  
		  int rownum = 1;
		txt_EmpNumb.sendKeys(XL.getCellValue("Z_SecurityManager", rownum , 6));
		  
		  WebElement btn_Search = driver.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[2]/table/tbody/tr/td/form/input"));
		  btn_Search.click();
		  WebElement link_Employee = driver.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[2]/table/tbody/tr/td/table/tbody/tr[2]/td[1]/a"));
		  link_Employee.click();
		  
		  WebElement info_Applications = driver.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[2]/table/tbody/tr/td/table[1]/tbody"));
		  if(info_Applications.getText().contains("SPS"))
		  {
			  
		  }
		  
//		  switch(XL.getCellValue("Z_SecurityManager", 1, 7))
//		  {
//		  case "SCHEDULER" : 
//		  
//		  }
//		  
	}
}
