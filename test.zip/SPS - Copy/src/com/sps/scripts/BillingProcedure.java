

	
	
/********************************************************************
Test Case Name: Create a New Surgical Request with Billing Procedure
Test Case ID: Use_198
Module: Regression Scripts
Created By: Rakesh Mankani
Date: 31st Sep 2015
**********************************************************************/



package com.sps.scripts;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.reports.CustomReporter;
import com.sps.pages.BaseClass;
import com.sps.pages.BillingProcedure_Page;
import com.sps.pages.Clinical_Info_Page;
import com.sps.pages.Login_Page;
import com.sps.pages.Request_info_Page;
import com.sps.pages.Search_MRN;

import common.Excel;
import common.Reusable_Methods;


public class BillingProcedure  extends BaseClass {
	
	
	Reusable_Methods RM;
	Excel XL;
	@BeforeTest
	public void propfilereader()
	{
		propertiesFileReader("src/objectrepository/SPS.properties");
		
		
	}

	
@Test
public void billingProc() throws InterruptedException{
	
	
	RM= new Reusable_Methods();
	XL = new Excel();
	String UN = property.getProperty("email");	
	String password = property.getProperty("password");
	String MRN = XL.getCellValue("BillingProcedure", 2, 6);
	System.out.println(MRN);
	String Surgeon = property.getProperty("Surgeon");
	//String Requestor = property.getProperty("Requestor");
	CustomReporter.log("Enter valid user id and password");
	Login_Page lp = new Login_Page(driver);
	lp.LoginSPS(UN, password);
	
	
	
	Search_MRN mrn = new Search_MRN(driver);
	
	mrn.SearchMRN(MRN);
	
	
	//Request_info_Page ReqInfo = new Request_info_Page(driver);
	//String pat = ReqInfo.RequestInfoSPS(Surgeon, driver);
	
	//CustomReporter.log("Info : " + pat);
	
	//Clinical_Info_Page ClinInfo = new Clinical_Info_Page(driver);
	//ClinInfo.ClinicalInfoSPS(driver);
	String CPT1 =  XL.getCellValue("BillingProcedure", 2, 7);
	String CPT2 = XL.getCellValue("BillingProcedure", 2, 8);
	String Diagnosis1 = XL.getCellValue("BillingProcedure", 2, 9);
	String Diagnosis2 = XL.getCellValue("BillingProcedure", 2, 10);
	
	BillingProcedure_Page BillProc = new BillingProcedure_Page(driver);
	BillProc.BillingProcSPS(CPT1, CPT2, Diagnosis1, Diagnosis2, driver);
	driver.close();
	
}
	


}

	
	

