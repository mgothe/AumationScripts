
/********************************************************************
Test Case Name: Validate business logic for Request Info section
Test Case ID: 
Module: Regression Scripts
Created By: Rakesh Mankani
Date: 28 Dec 2015
**********************************************************************/


package com.sps.scripts;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.reports.CustomReporter;
import com.sps.pages.BaseClass;
import com.sps.pages.Login_Page;
import com.sps.pages.Search_MRN;
import com.sps.validations.Location_validation;

public class Validation_RequestInfo_Section extends BaseClass {
	
	@BeforeTest
	public void propfilereader()
	{
		propertiesFileReader("src/objectrepository/SPS.properties");
	
	}
	
	
	@Test
	public void Validate_ReqInfo() throws InterruptedException{
		
		String UN = property.getProperty("email");	
		String password = property.getProperty("password");
		
		
		String MRN = property.getProperty("MRN");
		Login_Page lp = new Login_Page(driver);
		lp.LoginSPS(UN, password);
		CustomReporter.log("Login Succesfull");
		Search_MRN mrn = new Search_MRN(driver);
		mrn.SearchMRN(MRN);		
		Location_validation Loc = new Location_validation(driver);
		Loc.LocationValidationSPS(driver);
		
		driver.close();
		
		
		
		
		
	}

}
