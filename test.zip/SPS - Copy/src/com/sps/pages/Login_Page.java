package com.sps.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.reports.CustomReporter;

import common.Excel;
import common.Reusable_Methods;
import common.Excel;

public class Login_Page {

	
	public WebDriver driver;
	
	Reusable_Methods RM;
	Excel XL;

	
	public Login_Page(WebDriver driver) 
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		PageFactory.initElements(driver, this);
		RM= new Reusable_Methods();
		XL = new Excel();
	}
	
	@FindBy(xpath="//*[@id='username']")
	private WebElement txt_emailID;	
	
	
	@FindBy(xpath="//*[@id='password']")
	private WebElement txt_password;
	
	@FindBy(xpath="//input[@name='submit']")
	private WebElement btn_Login;
	
	
@FindBy(xpath="//span[contains(@class, 'ui-button')and contains(text(), 'Switch')]")
private WebElement btn_SwitchUser;
	
	@FindBy(xpath="//*[starts-with(@id,'menu')]/table/tbody/tr/td[1]")
	private WebElement btn_Home;
	
	
	public  void LoginSPS(String UN, String PWD) throws InterruptedException{	
		
		
        txt_emailID.clear();
		txt_emailID.sendKeys(UN);
		
		txt_password.clear();
		txt_password.sendKeys(PWD);	

		btn_Login.click();
		try{
		if (btn_SwitchUser.isEnabled())
		
			btn_SwitchUser.click();
		}
		catch(NoSuchElementException | ElementNotVisibleException e){
			CustomReporter.log("No Impersonation available for user " + XL.getCellValue("CreateRequest", 2, 4));
			return;
		}
		
			//	Thread.sleep(3000);
		//btn_Home.click();

}
	
	}

