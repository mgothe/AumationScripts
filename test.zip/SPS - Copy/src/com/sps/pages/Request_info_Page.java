package com.sps.pages;

import java.sql.Date;
import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.reports.CustomReporter;

import common.Reusable_Methods;

public class Request_info_Page  {
	
	public WebDriver driver;

	
					Reusable_Methods RM;
	
	
	



					public  Request_info_Page(WebDriver driver){
		
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					
					PageFactory.initElements(driver, this);
					RM= new Reusable_Methods();
	

}

	
					
	

	//@FindBy(xpath="id('_surgeonEmpId')/option[contains(text(),'Bae')]")
	//private WebElement select_surgeonSelect;	
	
	//To check default value of Surgeon
	
	@FindBy(xpath="//*[@id='_surgeonEmpId']/option[@selected='selected']")
	private WebElement default_surgeonSelect;
	
	
	@FindBy(xpath= "//*[@id='requestInfo.chbLocation.surgicalLocationCode1']")
	private WebElement chx_Bos;
	
	@FindBy(xpath= "//*[@id='requestInfo.chbLocation.surgicalLocationCode2']")
	private WebElement chx_Lex;
	
	@FindBy(xpath= "//*[@id='requestInfo.chbLocation.surgicalLocationCode3']")
	private WebElement chx_Wal;
	
	@FindBy(xpath= "//*[@id='requestInfo.chbLocation.surgicalLocationCode4']")
	private WebElement chx_GPU;
	
	@FindBy(xpath= "//*[@id='requestInfo.chbLocation.surgicalLocationCode5']")
	private WebElement chx_Oth;
	
	@FindBy(xpath= "//*[@id='roomTypeSelector']")
	private WebElement select_RoomArrow;
	
	@FindBy(xpath= "//*[@id='roomTypeSelector']/option[1]")
	private WebElement select_OR;
	
	@FindBy(xpath= "//Select[@id='roomTypeSelector']/option[normalize-space(text())='OR Procedure Room']")
	private WebElement select_Proc;
	
	@FindBy(xpath= "//*[@id='caseCategorySelector']")
	private WebElement select_CatArrow;
	
	@FindBy(xpath= "//*[@id='caseCategorySelector']/option[contains(text(), 'Fill')]")
	private WebElement select_CatFillToMax;
	
	@FindBy(xpath= "//*[@id='caseCategorySelector']/option[contains(text(), 'No Assigned')]")
	private WebElement select_CatPathology;
	
	@FindBy(xpath= "//*[@id='caseCategorySelector']/option[contains(text(), 'Pathology')]")
	private WebElement select_CatAssigned;
	
	@FindBy(xpath= "//*[@id='caseCategorySelector']/option[contains(text(), 'Social')]")
	private WebElement select_CatSocial;
	
	@FindBy(xpath= "//*[@id='caseCategorySelector']/option[contains(text(), 'Transport')]")
	private WebElement select_CatTransport;
	
	@FindBy(xpath= "//*[@id='caseCategorySelector']/option[contains(text(), 'MD')]")
	private WebElement select_CatMD;
	
	@FindBy(xpath= "//*[@id='caseCategorySelector']/option[contains(text(), 'Complex')]")
	private WebElement select_CatComplex;
	
	@FindBy(xpath= "//*[@id='caseCategorySelector']/option[contains(text(), 'Not Appropriate')]")
	private WebElement select_CatNotAppr;
	
	@FindBy(xpath= "//*[@id='caseCategorySelector']/option[contains(text(), 'Time')]")
	private WebElement select_CatTime;
	
	@FindBy(xpath= "//*[@aria-describedby='locationPreferenceDetails']//span[contains(text(), 'Save')]")
	private WebElement btn_SaveLoc;
	
	@FindBy(xpath= "//*[@id='locationPreferenceInfo']")
	private WebElement info_LocDetails;
			
	@FindBy(xpath= "//*[@id='requestInfo.admissionType1']")
	private WebElement chx_DSU;
		
	@FindBy(xpath= "//*[@id='requestInfo.admissionType2']")
	private WebElement chx_EXTD;
	
	@FindBy(xpath= "//*[@id='requestInfo.admissionType3']")
	private WebElement chx_Inpatient;
		
	@FindBy(xpath= "//*[@id='requestInfo.admissionType4']")
	private WebElement chx_SDA;
	
	@FindBy(xpath= "id('requestInfo.icuBedType2')")
	private WebElement chx_PostOp_Standard;
	
	@FindBy(xpath= "id('requestInfo.icuBedType3')")
	private WebElement chx_PostOp_ICU;
	
	@FindBy(xpath= "//*[@id='admittingServiceTypeSelector']")
	private WebElement select_AdmArrow;
	

	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Cardiology�Medicine')]")
	private WebElement select_Adm_CarMedicine;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Cardiovascular�Surgery')]")
	private WebElement select_Adm_CardSurgery;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Coordinated�Care�Services')]")
	private WebElement select_Adm_CoordinatedCare;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Dental')]")
	private WebElement select_Adm_Dental;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Dermatology')]")
	private WebElement select_Adm_Dermatology;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Endocrine')]")
	private WebElement select_Adm_Endocrine;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Epilepsy')]")
	private WebElement select_Adm_Epilepsy;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Gastroenterology')]")
	private WebElement select_Adm_Gastroenterology;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'General�Renal')]")
	private WebElement select_Adm_GenRenal;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'General�Surgery')]")
	private WebElement select_Adm_GenSurgery;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Genetics')]")
	private WebElement select_Adm_Genetics;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Gynecology')]")
	private WebElement select_Adm_Gynecology;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Hematology')]")
	private WebElement select_Adm_Hematology;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Immunocompromised�Service')]")
	private WebElement select_Adm_ImmService;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Immunology')]")
	private WebElement select_Adm_Immunology;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Infectious�Disease')]")
	private WebElement select_Adm_InfDisease;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Intensive�Care�Unit�(All)')]")
	private WebElement select_Adm_ICU;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Nephrology')]")
	private WebElement select_Adm_Nephrology;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Neurology')]")
	private WebElement select_Adm_Neurology;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Neurosurgery')]")
	private WebElement select_Adm_Neurosurgery;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Orthopaedcs/Hand')]")
	private WebElement select_Adm_OrthopaedcsHand;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Plastics/Hand')]")
	private WebElement select_Adm_PlasticsHand;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Rheumatology')]")
	private WebElement select_Adm_Rheumatology;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Solid�Organ�Transplant')]")
	private WebElement select_Adm_SOTransplant;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Solid�Organ�Transplant/Kidney')]")
	private WebElement select_Adm_SOTransplantKidney;
	@FindBy(xpath="//*[@id='admittingServiceTypeSelector']/option[contains(text(), 'Solid�Organ�Transplant/Pulmonary')]")
	private WebElement select_Adm_SOTransplantPulmonary;
	
	
    //private WebElement select_ArrivingFromArrow;
	
	@FindBy(xpath="//*[@id='patArrivingFromSelector']/option[contains(text(), 'Home')]")
	private WebElement select_ArrivingHome;
	
	@FindBy(xpath="//*[@id='patArrivingFromSelector']/option[contains(text(), 'BIDMC')]")
	private WebElement select_ArrivingBIDMC;
	
	@FindBy(xpath="//*[@id='patArrivingFromSelector']/option[contains(text(), 'BWH')]")
	private WebElement select_ArrivingBWH;
	
	@FindBy(xpath="//*[@id='patArrivingFromSelector']/option[contains(text(), 'DFCI')]")
	private WebElement select_ArrivingDFCI;
	
	@FindBy(xpath="//*[@id='patArrivingFromSelector']/option[contains(text(), 'Other')]")
	private WebElement select_ArrivingOther;
	
	@FindBy(xpath="//*[@aria-describedby='admissionPreferenceDetails']//span[contains(text(), 'Save')]")
	private WebElement btn_SaveAdm;
	
	
	@FindBy(xpath= "//*[@id='admissionPreferenceInfo']")
	private WebElement info_AdmDetails;
	
	
	@FindBy(xpath= "//*[@id='requestInfo.coordinatedCase1']")
	private WebElement chx_CoordYes;
	
	@FindBy(xpath= "//*[@id='requestInfo.coordinatedCase2']")
	private WebElement chx_CoordNo;
	
	@FindBy(xpath= "id('isPrimaryCase')")
	private WebElement chx_PrimCase;
	
	@FindBy(xpath= "//*[@id='coordinatingServiceSelector']/option[contains(text(), 'Orthopedics')]")
	private WebElement select_CoordServ_Ortho;
	
	@FindBy(xpath= "id('coordinatingSurgeonInput')")
	private WebElement txt_CoordSurg;
	
	@FindBy(xpath= "id('coordinatingNotes')")
	private WebElement txt_CoordNotes;
	
	@FindBy(xpath="//*[@aria-describedby='coordinateCaseDetails']//span[contains(text(), 'Save')]")
	private WebElement btn_SaveCoordCase;
	
	@FindBy(xpath="id('contactPhoneForCase')")
	private WebElement txt_ContactPhone;
	
	@FindBy(xpath="//*[@id='requestInfo.timeFrame.timeframeCode']/option[contains(text(), 'Family')]")
	private WebElement select_Timeframe;
	
	@FindBy(xpath= "//*[@id='timeFrameNotes']")
	private WebElement txt_Notes;
		
	@FindBy(xpath= "id('epicPrimaryLanguageInfo')")
	private WebElement info_PatLanguage;
	
	
	
	@FindBy(xpath= "id('interpreterSelect')/option[6]")
	private WebElement select_IntpLang_CAPE;
	
	
		
	@FindBy(xpath= "//*[@id='saveRequestBtn']")
	private WebElement btn_Save;
	
	
	
		public String RequestInfoSPS(String Surgeon, WebDriver driver) throws InterruptedException{
			
			
		
			try{
				
				//System.out.println(default_surgeonSelect.getText());
				//select_surgeonSelect.click();
				
				String xPath_Surgeon1 = "id('_surgeonEmpId')/option[contains(text(),'";
				String xPath_Surgeon2 = Surgeon +  "')]";
				String xPath_Surgeon = xPath_Surgeon1 + xPath_Surgeon2;
				System.out.println(xPath_Surgeon);
				try{
				WebElement srgn = driver.findElement(By.xpath(xPath_Surgeon));
				srgn.click();
				CustomReporter.log("Surgeon "+Surgeon+" is selected from the list");
				}
				catch(NoSuchElementException e){
					CustomReporter.errorLog("Surgeon "+Surgeon+" doesn't exist in the list");
					return null;
				}
																
				try{
					if(RM.elementExists(chx_Bos) == true)
					chx_Bos.click();	
					CustomReporter.log("Location Boston is set");
				}
				catch(NoSuchElementException | ElementNotVisibleException e){
					CustomReporter.errorLog("Boston location is not recognized in the application");
					return null;
				}
				
									
				//select_RoomArrow.click();
				
			
					
					select_Proc.click();
			
				
				
						
				//select_CatArrow.click();
				
				select_CatFillToMax.click();
				btn_SaveLoc.click();
				
				
				if(RM.compare(info_LocDetails.getText().trim(), "Fill to Max Blocktime, OR Procedure Room"))
				
				{
					
					CustomReporter.log("Location Preference set properly");
				}
				else{
					CustomReporter.errorLog("Location Preference not set properly");
				}
				
				 
				 chx_EXTD.click();
				 chx_PostOp_Standard.click();
				 //select_AdmArrow.click();
				 
				
				 select_Adm_Hematology.click();
				 select_ArrivingBIDMC.click();
				 
				 btn_SaveAdm.click();
				 
				 System.out.println(info_AdmDetails.getText().trim());
				 if(RM.compare(info_AdmDetails.getText().trim(), "1 Day; Standard; Hematology; From:..."))
				
					{
					 CustomReporter.log("Admission details set properly");
					}
				 else{
						CustomReporter.errorLog("Admission details not set properly");
					}
				 
				chx_CoordYes.click();
				select_CoordServ_Ortho.click();
				txt_CoordSurg.sendKeys("Testing the field Kasser, James");
				txt_Notes.sendKeys("Coordinated Case detils Testing");
				
				btn_SaveCoordCase.click();
				 
				
				
				txt_ContactPhone.sendKeys("1234567890");
				
				 
				 
				
			}
			
			
			catch(NoSuchElementException | ElementNotVisibleException e){
				CustomReporter.errorLog("Element not recognized. Please see log" );
				e.printStackTrace();
				
				
			}
			
			select_Timeframe.click();
			String PatLang = info_PatLanguage.getText();
			
			System.out.println(PatLang);
			
		
			/*if(info_PatLanguage.getText().length()-1 >26)
			{
				CustomReporter.log("Verify EPIC Primary Language info displayed ");
			}
			else
			{
				CustomReporter.errorLog("EPIC Primary Language info not displayed");
			}
			*/
			 txt_Notes.clear();
			 
			 
			
			 /*
		
			 Date date = new Date(System.currentTimeMillis());
	         String dateString = date.toString();
			 
			 
	*/
			 txt_Notes.sendKeys("Automated Script_NewReq created on " + getDateT() + " EST for Test script CREATE NEW REQUEST" );
		
			 
			 select_IntpLang_CAPE.click();
			 
			 
			 
			//btn_Save.click();
			System.out.println("Before");
			 CustomReporter.log("Save the request");
			 System.out.println("After");
			 return PatLang	;
						 
	}
		
		
		

		 private String getDateT()
		 {
		     DateFormat df = new SimpleDateFormat("yyyy-MM-dd_hh:mm:ss");
		     df.setTimeZone(TimeZone.getTimeZone("US/Eastern"));
		     return df.format(new Date(System.currentTimeMillis()));
		 }
				
}