package com.sps.pages;

import java.sql.Date;
import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;



import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.reports.CustomReporter;

import common.Reusable_Methods;


public class Clinical_Info_Page {
	
	public WebDriver driver;

	
	Reusable_Methods RM;






	public  Clinical_Info_Page(WebDriver driver){

	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	PageFactory.initElements(driver, this);
	RM= new Reusable_Methods();

}
	
	@FindBy(xpath="id('powerPlanPortlet')//label")
	private WebElement content_Powerplan;	
	
	@FindBy(xpath="id('ui-id-5')")
	private WebElement link_ClinInfo;
	
	@FindBy(xpath="id('ui-id-6')")
	private WebElement link_Scheduling;
	
	@FindBy(xpath="id('consults.consultCheckLists0.requested1')")
	private WebElement chx_AnesthesiaConsult;
	
	@FindBy(xpath="id('consults.consultCheckLists1.requested1')")
	private WebElement chx_CardiacAnest;
	
	@FindBy(xpath="id('consults.consultCheckLists4.requested1')")
	private WebElement chx_DentalConsult;
	
	@FindBy(xpath="id('consults.consultCheckLists11.requested1')")
	private WebElement chx_PhysicalConsult;
	
	@FindBy(xpath="//form[@id='clinicalInfoForm']/@action")
	private WebElement info_RequestIDLink;
	
	
	public void ClinicalInfoSPS(WebDriver driver) throws InterruptedException{
		
		//driver.get("http://chwebtest.tch.harvard.edu/sps/spring/request/id/1165");
		
		
		link_ClinInfo.click();
		String URL = driver.getCurrentUrl();
		String requestID = RM.splitString(URL, "id/", "\\?");
		CustomReporter.log("New Request created with Request ID " +requestID);
		
		if(RM.compare(content_Powerplan.getText().trim(), "Go into PowerChart to create orders"))
		{
			
			CustomReporter.log("CH-Menu Powerplan message displayed properly");
		}
		
		else{
			CustomReporter.errorLog("Fail - CH-Menu Powerplan message not displayed properly");
		}
		
		
		
		
		chx_AnesthesiaConsult.click();
		chx_CardiacAnest.click();
		chx_DentalConsult.click();
		chx_PhysicalConsult.click();
		
		
		link_Scheduling.click();
		
		
		
		
		return;
		
}	
}	
