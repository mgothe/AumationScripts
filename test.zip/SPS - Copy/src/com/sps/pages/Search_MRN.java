package com.sps.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.reports.CustomReporter;

import common.Reusable_Methods;
import common.Excel;

public class Search_MRN {
	
public WebDriver driver;
	
	Reusable_Methods RM;
	Excel XL;
	
	public Search_MRN(WebDriver driver)
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		PageFactory.initElements(driver, this);
		RM= new Reusable_Methods();
		XL = new Excel();
				
	}
	
	@FindBy(xpath="//*[@id='mrnInput']")
	private WebElement searchMRNtxt;	
	
	@FindBy(xpath="//*[@value='Create New Request']")
	private WebElement createNewReq;	
	
	@FindBy(xpath="id('selectDeptTeamDlg')")
	private WebElement SelectDeptDlg;	
	
	@FindBy(xpath="id('deptTeamSelector')")
	private WebElement SelectDeptDropdown;
	
	@FindBy(xpath="id('deptTeamSelector')/option[3]")
	private WebElement SelectOrthoUE;
	
	@FindBy(xpath="//button[@type='button' and span='Select']")
	private WebElement btn_Select;
	
	@FindBy(xpath="id('requestorInfoBlock')")
	private WebElement info_DeptName;
	
	
public  void SearchMRN(String mrn) throws InterruptedException{	
		
	
	//System.out.println(XL.getCellValue("CreateRequest", 2, 6));	
	searchMRNtxt.click();
	searchMRNtxt.sendKeys(mrn);
	System.out.println(mrn);
	
	createNewReq.click();
	CustomReporter.log( mrn +" is the MRN used to create new request" );
	
	
	if (SelectDeptDlg.isDisplayed())
	{
		//SelectDeptDropdown.click();
		//SelectOrthoUE.click();
		SelectOrthoUE.click();
		//Thread.sleep(2000);
		btn_Select.click();
	}
	
	
	
	CustomReporter.log( info_DeptName.getAttribute("value")+ "  is the Department/Team" );
}
}
