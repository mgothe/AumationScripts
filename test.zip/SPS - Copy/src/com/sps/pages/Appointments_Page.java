package com.sps.pages;

import java.sql.Date;
import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.reports.CustomReporter;

import common.Reusable_Methods;

public class Appointments_Page {

	
	public WebDriver driver;

	
	Reusable_Methods RM;






	public  Appointments_Page (WebDriver driver){

	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	PageFactory.initElements(driver, this);
	RM= new Reusable_Methods();


}
	
	@FindBy(xpath="id('appointments.appointmentCheckLists0.requested1')")
	private WebElement chx_preOpDeptAppt;
	
	@FindBy(xpath="id('appointments.appointmentCheckLists1.requested1')")
	private WebElement chx_2wkpostOp;
	
	@FindBy(xpath="id('appointments.appointmentCheckLists2.requested1')")
	private WebElement chx_6wkpostOp;
	
	@FindBy(xpath="id('appointments.appointmentCheckLists3.requested1')")
	private WebElement chx_preOpTeaching;
	
	@FindBy(xpath="id('appointments.appointmentCheckLists4.requested1')")
	private WebElement chx_castRem;
	
	@FindBy(xpath="id('appointments.appointmentCheckLists5.requested1')")
	private WebElement chx_preOpClinAppt;
	
	@FindBy(xpath="id('appointments.appointmentCheckLists6.requested1')")
	private WebElement chx_preOpScreenAppt;
	
	@FindBy(xpath="id('appointments.appointmentCheckLists7.requested1')")
	private WebElement chx_sameDay;

	
	@FindBy(xpath="id('appointments.appointmentCheckLists0.requestedReason')")
	private WebElement txt_preOpReason;
	
	@FindBy(xpath="id('appointments.appointmentCheckLists1.requestedReason')")
	private WebElement txt_2wkOpReason;

	@FindBy(xpath="id('appointments.appointmentCheckLists2.requestedReason')")
	private WebElement txt_6wkOpReason;
	
	@FindBy(xpath="id('appointments.appointmentCheckLists5.requestedReason')")
	private WebElement txt_preOpClinReason;
	
	@FindBy(xpath="id('appointments.appointmentCheckLists6.requestedReason')")
	private WebElement txt_preOpScreenReason;
	
	@FindBy(xpath="id('appointments.appointmentCheckLists7.requestedReason')")
	private WebElement txt_sameDayReason;
	
	@FindBy(xpath="id('ui-id-6')")
	private WebElement link_Scheduling;

	@FindBy(xpath="id('appointmentCheckListPortlet')/div[2]/table/tbody/tr/td/table/tbody/tr[1]/td[1]/label")
	private WebElement info_Preadmit;
	
	@FindBy(xpath="id('appointmentCheckListPortlet')/div[2]/table/tbody/tr/td/table/tbody/tr[2]/td[1]/label")
	private WebElement info_PreOpDept;
	
	@FindBy(xpath="id('appointmentCheckListPortlet')/div[2]/table/tbody/tr/td/table/tbody/tr[3]/td[1]/label")
	private WebElement info_2wk;
	
	@FindBy(xpath="id('appointmentCheckListPortlet')/div[2]/table/tbody/tr/td/table/tbody/tr[4]/td[1]/label")
	private WebElement info_6wk;
	
	@FindBy(xpath="id('appointmentCheckListPortlet')/div[2]/table/tbody/tr/td/table/tbody/tr[5]/td[1]/label")
	private WebElement info_PreopTeaching;
	
	@FindBy(xpath="id('appointmentCheckListPortlet')/div[2]/table/tbody/tr/td/table/tbody/tr[6]/td[1]/label")
	private WebElement info_CastRem;
	
	@FindBy(xpath="id('appointmentCheckListPortlet')/div[2]/table/tbody/tr/td/table/tbody/tr[7]/td[1]/label")
	private WebElement info_PreopClin;
	
	@FindBy(xpath="id('appointmentCheckListPortlet')/div[2]/table/tbody/tr/td/table/tbody/tr[8]/td[1]/label")
	private WebElement info_PreOpScreen;
	
	@FindBy(xpath="id('appointmentCheckListPortlet')/div[2]/table/tbody/tr/td/table/tbody/tr[9]/td[1]/label")
	private WebElement info_SameDay;

	@FindBy(xpath= "//*[@id='timeFrameNotes']")
	private WebElement txt_Notes;

	
public void AppointmentSPS(WebDriver driver) throws InterruptedException{
	
	txt_Notes.clear();
	 txt_Notes.sendKeys("Automated Script_NewReq created on " + getDateT() + " EST  for Test script on APPOINTMENTS" );
	
	chx_preOpDeptAppt.click();
	chx_2wkpostOp.click();
	chx_6wkpostOp.click();
	chx_preOpTeaching.click();
	chx_castRem.click();
	chx_preOpClinAppt.click();
	//chx_preOpScreenAppt.click();
	//chx_sameDay.click();
	
	
	txt_preOpReason.sendKeys("Reason 1 - Automated testing");
	
	txt_2wkOpReason.sendKeys("Reason 2 - Automated testing");
	
	txt_6wkOpReason.sendKeys("Reason 3 - Automated testing");
	
	txt_preOpClinReason.sendKeys("Reason 4 - Automated testing");
	
	txt_preOpScreenReason.sendKeys("Reason 7 - Automated testing");
	
	txt_sameDayReason.sendKeys("Reason 8 - Automated testing");
	
	link_Scheduling.click();
	
	System.out.println(info_Preadmit.getText());
	try{
	if(info_Preadmit.isDisplayed())
	CustomReporter.log("Preadmit shcheduled in EPIC is found");
	}
	catch(NoSuchElementException e)
	{
		CustomReporter.errorLog("Error- Preadmit shcheduled in EPIC is not found");
	}
	
	try{
	if(info_PreOpDept.isDisplayed())
	
		CustomReporter.log("Pre-Op Departmental Appt is found");
	}
	catch(NoSuchElementException e){
		CustomReporter.errorLog("Error- Pre-Op Departmental Appt is not found");
	
	}
	
	try{
	if(info_2wk.isDisplayed())
	
		CustomReporter.log("2 Week Post-Op Appt");
	}
	catch(NoSuchElementException e){
		CustomReporter.errorLog("Error- 2 Week Post-Op Appt is not found");
	}
	
	try{
	if(info_6wk.isDisplayed())
	
		CustomReporter.log("6 Week Post-Op Appt");
	}
	catch(NoSuchElementException e){
		CustomReporter.errorLog("Error- 6 Week Post-Op Appt is not found");
	}
	
	try{
	if(info_PreopTeaching.isDisplayed())
	
		CustomReporter.log("Pre-Op Teaching Crutch Walking is found");
	}
	catch(NoSuchElementException e){
		CustomReporter.errorLog("Error- Pre-Op Teaching Crutch Walking is not found");
	}
	
	
	
	try{
	if(info_CastRem.isDisplayed())
	
		CustomReporter.log("Cast Removal is found");
	}
	catch(NoSuchElementException e){
		CustomReporter.errorLog("Error- Cast Removal is not found");
	}
	
	try{
	if(info_PreopClin.isDisplayed())
	
		CustomReporter.log("Pre-Op Clinic Appt is found");
	}
	catch(NoSuchElementException e){
		CustomReporter.errorLog("Error- Pre-Op Clinic Appt is not found");
	}
	
	try{
	if(info_PreOpScreen.isDisplayed())
	
		CustomReporter.log("Pre-Op Screening Call is found");
	}
	catch(NoSuchElementException e){
		CustomReporter.errorLog("Error- Pre-Op Screening Call is not found");
	}
	
	try{
	if(info_SameDay.isDisplayed())
	
		CustomReporter.log("Same Day Workup Appt is found");
	}
	catch(NoSuchElementException e){
		CustomReporter.errorLog("Error- Same Day Workup Appt is not found");
	}
	
	
	
	return;
}
private String getDateT()
{
    DateFormat df = new SimpleDateFormat("yyyy-MM-dd_hh:mm:ss");
    df.setTimeZone(TimeZone.getTimeZone("US/Eastern"));
    return df.format(new Date(System.currentTimeMillis()));
}

}