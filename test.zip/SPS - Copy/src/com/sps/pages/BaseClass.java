package com.sps.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;




//import com.msat.frameworks.data_driven.base.Base;
import common.Reusable_Methods;

public class BaseClass extends Reusable_Methods {
	
	public static WebDriver driver;
	public static Properties property;
	public static boolean testCaseStatus = true;
	
	@Parameters({ "browser"})
	@BeforeMethod
	
	public void startBrowser(String browser){	
		propertiesFileReader("src/objectrepository/SPS.properties");
		if (browser.contentEquals("firefox"))
		{
		driver = new FirefoxDriver();
		driver.get(property.getProperty("URL"));
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		}
		else if(browser.contentEquals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "Browser Servers"+File.separator+"chromedriver.exe");
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		    capabilities.setCapability("chrome.switches", Arrays.asList("--start-maximized","--disable-popup-blocking"));
		   driver = new ChromeDriver(capabilities);
		   driver.get("http://172.19.50.32:8080/idiom/#/login");
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			driver.manage().window().maximize();
		}
		else if(browser.contentEquals("chrome"))
		{
			
		}
	}
	
	@AfterMethod
	public void closeBrowser(){
		//driver.quit();
	}
	public static void propertiesFileReader(String filePath)
	{
		property = new Properties();
		try {
			property.load(new FileInputStream(filePath));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	

}
