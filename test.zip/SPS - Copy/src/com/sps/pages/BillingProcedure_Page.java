package com.sps.pages;

import java.sql.Date;
import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.reports.CustomReporter;

import common.Reusable_Methods;

public class BillingProcedure_Page  {
	
public WebDriver driver;

	
	Reusable_Methods RM;
	
	public  BillingProcedure_Page (WebDriver driver){

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		PageFactory.initElements(driver, this);
		RM= new Reusable_Methods();


	}
	
	
	
	@FindBy(xpath= "//*[@id='timeFrameNotes']")
	private WebElement txt_Notes;
	
	@FindBy(xpath= "id('cptProcSearchTerm')")
	private WebElement txt_cptProcSearch;
			
	@FindBy(xpath= "id('cptTerminologySearch-hliSearchTerm')")
	private WebElement txt_cptProcSearchHLI;
	
	@FindBy(xpath= "id('cptTerminologySearch-searchResultsBody')/tr/td[1]")
	private WebElement select_cptProcSearchRow1;
			
	@FindBy(xpath= "id('diagSearchTerm')")
	private WebElement txt_diagSearch;
	
	@FindBy(xpath= "id('diagnosisTerminologySearch-hliSearchTerm')")
	private WebElement txt_diagSearchHLI;
	
	
	@FindBy(xpath= "id('diagnosisTerminologySearch-searchResultsBody')/tr/td[1]")
	private WebElement select_diagSearchRow1;
			
 
	@FindBy(xpath= "id('diagnosisTerminologySearch-icd10ResultsBody')/tr[1]/td[1]")
	private WebElement txt_diagSearchAttribRow1;
		
	@FindBy(xpath="id('ui-id-5')")
	private WebElement link_ClinInfo;
	
	public void BillingProcSPS(String CPT1, String CPT2, String Diagnosis1, String Diagnosis2, WebDriver driver) throws InterruptedException{	
		
	
	txt_Notes.sendKeys("Automated Script_NewReq created on " + getDateT() + " EST for Test script BILLING PROCEDURE" );
	
	txt_cptProcSearch.sendKeys(CPT1);
	txt_cptProcSearchHLI.clear();
	txt_cptProcSearchHLI.sendKeys(CPT1);
	select_cptProcSearchRow1.click();
	
	txt_diagSearch.clear();
	txt_diagSearch.sendKeys(Diagnosis1);
	Thread.sleep(1000);
	txt_diagSearchHLI.clear();
	txt_diagSearchHLI.sendKeys(Diagnosis1);
	select_diagSearchRow1.click();
	txt_diagSearchAttribRow1.click();
	
	txt_cptProcSearch.clear();
	txt_cptProcSearch.sendKeys(CPT2);
	txt_cptProcSearchHLI.clear();
	txt_cptProcSearchHLI.sendKeys(CPT2);
	select_cptProcSearchRow1.click();
	
	txt_diagSearch.sendKeys(Diagnosis2);
	Thread.sleep(1000);
	txt_diagSearchHLI.clear();
	txt_diagSearchHLI.sendKeys(Diagnosis2);
	Thread.sleep(5000);
	select_diagSearchRow1.click();
	txt_diagSearchAttribRow1.click();

	link_ClinInfo.click();
	Thread.sleep(2000);
	String URL = driver.getCurrentUrl();
	String requestID = RM.splitString(URL, "id/", "\\?");
	CustomReporter.log("New Request created with Request ID " +requestID);
	CustomReporter.log("CPT and Diagnosis are successfully added");
}
	
	private String getDateT()
	 {
	     DateFormat df = new SimpleDateFormat("yyyy-MM-dd_hh:mm:ss");
	     df.setTimeZone(TimeZone.getTimeZone("US/Eastern"));
	     return df.format(new Date(System.currentTimeMillis()));
	 }
}
