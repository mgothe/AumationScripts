package com.sps.validations;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import common.Reusable_Methods;

public class Scratchpad_validation {

	
	
public WebDriver driver;

	
	Reusable_Methods RM;






	public  Scratchpad_validation(WebDriver driver){

	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	PageFactory.initElements(driver, this);
	RM= new Reusable_Methods();

	
}
	
	/* Xpath To get all rows in the scratchpad
	 * //*[@id="scratchPadPortlet"]/div/div/div/table/tbody
	 */
	

	
	
}