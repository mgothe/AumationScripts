package com.sps.validations;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.reports.CustomReporter;

import common.Reusable_Methods;

public class Location_validation {
	
	public WebDriver driver;

	
	Reusable_Methods RM;






	public  Location_validation(WebDriver driver){

	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	PageFactory.initElements(driver, this);
	RM= new Reusable_Methods();


}
	@FindBy(xpath= "//*[@id='requestInfo.chbLocation.surgicalLocationCode1']")
	private WebElement chx_Bos;
	
	@FindBy(xpath= "//*[@id='requestInfo.chbLocation.surgicalLocationCode2']")
	private WebElement chx_Lex;
	
	@FindBy(xpath= "//*[@id='requestInfo.chbLocation.surgicalLocationCode3']")
	private WebElement chx_Wal;
	
	@FindBy(xpath= "//*[@id='requestInfo.chbLocation.surgicalLocationCode4']")
	private WebElement chx_Other;
	
	
	
	@FindBy(xpath= "id('locationPreferenceDetails')")
	private WebElement dialog_LocationDetails;
	
	@FindBy(xpath= "id('locationPreferenceInfo')")
	private WebElement info_LocPref;
	
	@FindBy(xpath= "id('roomTypeSelector')/option[1]")
	private WebElement field_LocOR;
	
	@FindBy(xpath= "id('caseCategorySelector')/option[1]")
	private WebElement field_caseCategory_select;
	
	
	@FindBy(xpath= "//*[@aria-describedby='locationPreferenceDetails']//span[contains(text(), 'Save')]")
	private WebElement btn_SaveLoc;
	
	public void LocationValidationSPS(WebDriver driver) throws InterruptedException{
		
	// For Boston location	
		chx_Bos.click();
		
		if(RM.elementExists(dialog_LocationDetails)==true)
		{
			CustomReporter.log("Location Details pop-up opens for location BOSTON");
			
		}
		else
		{
			CustomReporter.errorLog("Location Details pop-up not displayed");
			
		}
		
		
		
		if(RM.compare(field_LocOR.getText().trim(), "OR"))
		
		{
		    CustomReporter.log("Default Room Type for Boston is OR");
		}
		else
			CustomReporter.errorLog("Default Room Type for Boston is not OR");
		
String LocationDetailsItems = "Room TypeOROR Procedure RoomCase Category--Select--Fill to Max BlocktimeNo Assigned Sat BlockPathology RequiredSocial IssuesTransport LimitationMD Coordinated CaseComplex Med HxNot Appropriate for SatTime Sensitive Case";
	


if(RM.compare(field_caseCategory_select.getText().trim().replaceAll("\n", ""), "--Select--"))
	
{
    CustomReporter.log("Case Category doesnt default and is set to --Select--");
}
else
	CustomReporter.errorLog("Case Category not set to --Select--");

System.out.println(dialog_LocationDetails.getText());
		
	
if(RM.compare(dialog_LocationDetails.getText().replaceAll("\n", ""), LocationDetailsItems))
			
		{
		    CustomReporter.log("All fields in Location Details dialog are in order");
		}
		else
			CustomReporter.errorLog("Some change in the fields order for Location Details Dialog identified");
		
		
btn_SaveLoc.click();

		//For Lexington location	
				chx_Lex.click();
		
				if(RM.compare(info_LocPref.getText().trim(), "Appropriate for Satellites, OR"))
				{
					CustomReporter.log("Lexington Location Read-only info set as - Appropriate for Satellites, OR");
				}
				else
				{
					CustomReporter.errorLog("Lexington Location read-only is NOT displaying - Appropriate for Satellites, OR");
				}
		
		//For Waltham location	
				chx_Wal.click();

				if(RM.compare(info_LocPref.getText().trim(), "Appropriate for Satellites, OR"))
				{
					CustomReporter.log("Waltham Location Read-only info set as - Appropriate for Satellites, OR");
				}
				else
				{
					CustomReporter.errorLog("Waltham Location read-only is NOT displaying - Appropriate for Satellites, OR");
				}	
		
		
				//For Other location	
				chx_Other.click();

				if(RM.compare(info_LocPref.getText().trim(), "Appropriate for Satellites, OR"))
				{
					CustomReporter.log("Waltham Location Read-only info set as - Appropriate for Satellites, OR");
				}
				else
				{
					CustomReporter.errorLog("Waltham Location read-only is NOT displaying - Appropriate for Satellites, OR");
				}	

}
}
