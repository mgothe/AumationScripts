package common;

import java.awt.AWTException;
import java.awt.List;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.openqa.selenium.Keys;

import com.msat.frameworks.data_driven.base.Base;
import com.reports.CustomReporter;
import com.sps.pages.BaseClass;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Reusable_Methods extends Base{

	public static WebDriver driver;
	public static Properties property;
	public static String ParentWindowID = "";
	public static Date date = new Date();
	
	public static void startBrowser(String browser, String url)
	{
		if(browser.equalsIgnoreCase("firefox"))
			driver = new FirefoxDriver();
		else if(browser.equalsIgnoreCase("chrome"))
		{			
			System.setProperty("webdriver.chrome.driver","C:\\IDIOM Project\\IDIOM\\Browser Servers\\chromedriver.exe");
			
			driver = new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("iexplorer"))
		{			
			System.setProperty("webdriver.ie.driver","C:\\IDIOM Project\\IDIOM\\Browser Servers\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	public static void propertiesFileReader(String filePath)
	{
		property = new Properties();
		try {
			property.load(new FileInputStream(filePath));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	
	

	public static void switchToNewWindow()
	{		
		ParentWindowID = driver.getWindowHandle();

		for (String winHandle : driver.getWindowHandles()) {	    	
			if(!ParentWindowID.equalsIgnoreCase(winHandle))
			{
				driver.switchTo().window(winHandle);
			}
		}
	}

	public static void switchToOriginalWindow()
	{		
		driver.switchTo().window(ParentWindowID);	
	}


	

	
	public static void createTextFile(String path) throws InterruptedException, IOException
	{
		 //Create File In D: Driver.  
		  String TestFile = path;
		  File FC = new File(TestFile);//Created object of java File class.
		  FC.createNewFile();//Create file.	
		  
		  //Writing In to file.
		  //Create Object of java FileWriter and BufferedWriter class.
		  FileWriter FW = new FileWriter(TestFile);
		  BufferedWriter BW = new BufferedWriter(FW);
		  BW.write("This Is First Line."); //Writing In To File.
		  BW.newLine();//To write next string on new line.
		  BW.write("This Is Second Line."); //Writing In To File.
		  BW.close();		  
		
	}
	
	public static void deleteTextFile(String path) throws InterruptedException, IOException
	{
		System.out.println("Deleting Text File Created in Temp Folder");
		 //Create File In D: Driver.  
		  String TestFile = path;
		  File FC = new File(TestFile);//Created object of java File class.
		  FC.delete();   
		  
		
	}

	
	// Generate random number
	public static String randomNumber()
	{	
		String randomNumber = "";
		randomNumber = String.valueOf(date.getTime());
		
		return randomNumber;
	}
	
	
	
	public static void selectDropDrownValue(WebElement element, String value){
		try{
			Select select= new Select(element);
			select.selectByVisibleText(value);
		}
		catch(Exception e){
			e.printStackTrace();
			Assert.assertTrue(false);
		}
	}
	
	
	
	public static void selectDropDrown(WebElement element, String value){
		try{
			Select select= new Select(element);
			select.selectByValue(value);
		}
		catch(Exception e){
			e.printStackTrace();
			Assert.assertTrue(false);
		}
	}	
	
	
	
	public static void DeleteEmail(String subject)
    {           
          driver.findElement(By.xpath(property.getProperty("button_Promotions"))).isDisplayed();
          driver.findElement(By.xpath(property.getProperty("button_Promotions"))).click();
          driver.findElement(By.xpath("//div[@class = 'y6']/span[contains(., '"+subject+"')]")).click();
        
          driver.findElement(By.xpath(property.getProperty("button_Delete"))).click();                      
                     
    }
	
	public static String monthFormat(int month)
    {    String  monthString; 
    
		switch (month) {
        case 1:  monthString = "Jan";
                 break;
        case 2:  monthString = "Feb";
                 break;
        case 3:  monthString = "Mar";
                 break;
        case 4:  monthString = "Apr";
                 break;
        case 5:  monthString = "May";
                 break;
        case 6:  monthString = "Jun";
                 break;
        case 7:  monthString = "Jul";
                 break;
        case 8:  monthString = "Aug";
                 break;
        case 9:  monthString = "Sep";
                 break;
        case 10: monthString = "Oct";
                 break;
        case 11: monthString = "Nov";
                 break;
        case 12: monthString = "Dec";
                 break;
        default: monthString = "Invalid month";
                 break;
    }  
		return monthString;
                     
    }
	
	
	
	public static void highlightElement(WebElement element) {
        for (int i = 0; i <3; i++) {
        	JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "color: red; border: 2px solid red;");
            js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
            }
        }
	
	
	public boolean elementExists(WebElement element){
		boolean value = false;
		String elementName = element.getText();
		try{
		if (element.isDisplayed()){			
			value=true;
		}
		
		else{
			value=false;
			CustomReporter.errorLog(elementName+" is NOT displayed");			
			BaseClass.testCaseStatus=false;
		}
		
		} catch(Exception e){
			e.printStackTrace();
		}
		return value;
		
		
		
	}
	//Updated by Amutha Nair
	public Boolean webElementExists(java.util.List<WebElement> input){
		
		Boolean value;
		if (input.size()!=0){			
			value=true;
		}else{
			value=false;
		}
		return value;		
		
	}
	
	//This method retrieves data from DB based on query provided
	//Date:27 july 2015
	
	public Hashtable RetrieveValuesFromDB(String Query)
	{
		Statement stmt;
		Integer ValueOutput=0; 
		Float ValueOut=(float) 0;
	
		try {
 
			Class.forName("org.postgresql.Driver");
 
		} catch (ClassNotFoundException e) {
 
		
			e.printStackTrace();
			//return;
 
		}
		
		Connection connection = null;
 
		try {
 
			
			  connection = DriverManager.getConnection("jdbc:postgresql://idiomqapsql02.c1dw3w2xwiv0.us-east-1.rds.amazonaws.com:5432/IDQAPSQL01","psqladm", "IPJ3oHIBx28miyJVUoTh1wtZ");
            
              stmt = connection.createStatement();
              ResultSet res = stmt.executeQuery(Query);
              Hashtable<String, Integer> ht = new Hashtable<String, Integer>();


       while (res.next())
       {
	
	ValueOut=res.getFloat(2);	
	ValueOutput=(Integer) Math.round(ValueOut);
	ht.put(res.getString(1), ValueOutput);
	
	 }
return ht;
		} catch (SQLException e) {
			 
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			
		}
 
		if (connection != null) {
		
		} else {
			System.out.println("Failed to make connection!");
		}
		
		return null;
		
	}
	
	
	
	//This method inserts data into DB based on query provided
	//Date:5th August 2015

	public Boolean InsertDataInDB(String Query)
	{
			Statement stmt;			
			Boolean done= true;
			try {
	 
				Class.forName("org.postgresql.Driver");
	 
			} catch (ClassNotFoundException e) {
	 
			
				e.printStackTrace();
				//return;
	 
			}
			
			Connection connection = null;
	 
			try {
	 
				
				  connection = DriverManager.getConnection("jdbc:postgresql://idiomqapsql02.c1dw3w2xwiv0.us-east-1.rds.amazonaws.com:5432/IDQAPSQL01","psqladm", "IPJ3oHIBx28miyJVUoTh1wtZ");
	            
	              stmt = connection.createStatement();
	              
	              stmt.executeUpdate(Query);
	             // stmt.executeQuery(Query);
	           
	return done;
			} catch (SQLException e) {
				 
				System.out.println("Connection Failed! Check output console");
				e.printStackTrace();
				done=false;
				
			}
	 
			if (connection != null) {
			
			} else {
				System.out.println("Failed to make connection!");
				done=false;
			}
			
			return done;
			
		}
		
		public void clickWebElement(WebElement element){
			
			element.click();		
			
		}
		
		public void waitTime(long seconds){
			try {
				Thread.sleep(seconds);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		//This method gets the previous year
		//Date:7th August 2015
		
		
		public String  getPreviousYear() {
			
			String pYear=null;
		    Calendar prevYear = Calendar.getInstance();
		    prevYear.add(Calendar.YEAR, -1);
		    pYear=String.valueOf(prevYear.get(Calendar.YEAR));
		   // return prevYear.get(Calendar.YEAR);
			return pYear;
		
		}
		
		//This method gets the months 
		//Date:7th August 2015
	
		public boolean  checkMonth(String month) {
			boolean found=false;
		String[] months = new DateFormatSymbols().getMonths();
	    for (int i = 0; i < months.length; i++) {
	        if(months[i].contentEquals(month))
	        {
	        	CustomReporter.log("The month is "+months[i]);
	        	found = true;
	        	break;
	        }
	    }
		return found;
		}
		
	
	//This method checks whether the date given is in the date range 
	// Date:7th Augus 2015
	
		public boolean dateRange(String date, String month){
			boolean found=false;
			int dateInt= Integer.parseInt(date);
			if ((month.contentEquals("January")||month.contentEquals("March")||month.contentEquals("May")||month.contentEquals("July")||month.contentEquals("August")||month.contentEquals("October")||month.contentEquals("December"))&&(dateInt>0 && dateInt<32)){
				CustomReporter.log("The date is valid ");
				found= true;
			}
			else if((month.contentEquals("April")||month.contentEquals("June")||month.contentEquals("September")||month.contentEquals("November")||month.contentEquals("February"))&&(dateInt>0 && dateInt<31)){
				CustomReporter.log("The date is valid ");
				found= true;
			}
			else{
				CustomReporter.errorLog("The date is  not valid ");
			}
			return found;
					
		}
		
		//This method checks whether the time is valid 
		//Date:7th August 2015
		
		public boolean timeRange(String time){
			boolean found=false;
		    String[] timeArray =time.split(":");
		    System.out.println(timeArray[0]+","+timeArray[1]);
		    int hour=Integer.parseInt(timeArray[0]);
		    int minute=Integer.parseInt(timeArray[1]);
		    if(hour>0 && hour<13){
		    	if(minute>0 && minute<60)
		    	{
		    		CustomReporter.log("Time is valid "+time);
		    		found=true;
		    	}
		    }
		    else{
		    	CustomReporter.errorLog("Invalid Time:"+time);
		    }
			return found;
					
		}
		
		public boolean compare(String str1, String str2) {
		    return (str1 == null ? str2 == null : str1.equals(str2));
		}

		//This method compares two strings with different legths 
		//Date:7th August 2015
		
		public boolean compareString(String[] string1, String[] string2){
			boolean status=true;
		for (String s1:string1){
			for (int i=0;i<=string2.length;i++){
				if(s1.contentEquals(string2[i])){
					status=true;
				}
				else{
					status=false;
					break;
				}
			}
		}
			return status;
					
		}
		
		
				
		public String splitString(String Url, String Delimiter1, String Delimiter2){
			
			
			String[] parts = Url.split(Delimiter1);
			//String part1 = parts[0]; 
			String part2 = parts[1]; 
			String[] Url2 = part2.split(Delimiter2);
			String part3=Url2[0];
					
			
			
		
			return part3;
					
		}
		
}


	

	

