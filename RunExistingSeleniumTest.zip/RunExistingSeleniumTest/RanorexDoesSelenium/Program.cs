﻿/*
 * Created by Ranorex
 * User: copresnik
 * Date: 02.03.2017
 * Time: 13:38
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Threading;
using System.Drawing;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Reporting;
using Ranorex.Core.Testing;

namespace RanorexDoesSelenium
{
    class Program
    {
        [STAThread]
        public static int Main(string[] args)
        {
            // Uncomment the following 2 lines if you want to automate Windows apps
            // by starting the test executable directly
            //if (Util.IsRestartRequiredForWinAppAccess)
            //    return Util.RestartWithUiAccess();

            Keyboard.AbortKey = System.Windows.Forms.Keys.Pause;
            int error = 0;
            
            
            
            SeleniumTools st = new SeleniumTools();
        	
        	st.RunTestSynchronized("mvn", 
				"clean test surefire-report:report", 
				@"C:\Users\meric\workspace\BCHSPSQA");
        	
        	st.ParseExtTestResults(@"C:\Users\meric\workspace\BCHSPSQA", 
				@"\target\surefire-reports\TEST-TestSuite.xml");
            

            try
            {
                error = TestSuiteRunner.Run(typeof(Program), Environment.CommandLine);
            }
            catch (Exception e)
            {
                Report.Error("Unexpected exception occurred: " + e.ToString());
                error = -1;
            }
            return error;
        }
        
    }
}
