package com.bch.sps.qa.testcases;

import org.junit.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.bch.sps.qa.common.TestCommon;
import com.bch.sps.qa.pages.HomePage;
import com.bch.sps.qa.pages.LoginPage;

public class LoginPageTest extends TestCommon{
	
	LoginPage loginPage;
	HomePage homePage;
	
	public LoginPageTest(){
		super();// will call the TestCommon constructor using the super keyword.
	}
	
	
	@BeforeMethod
	public void setUp(){
		initialization();
		loginPage  = new LoginPage();
	}
	
	//Actual test cases start from @Test annotation.
	@Test(priority=2)
	public void loginPageTitleTest(){
		String title = loginPage.validateLoginPageTitle();
		Assert.assertEquals(title, "CRM");
	}
	
	@Test(priority=1) //now have to pass the user and pass from properties
	public void loginTest(){
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
		System.out.println("Login Success"+ prop.getProperty("username"));
	}
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}

}
