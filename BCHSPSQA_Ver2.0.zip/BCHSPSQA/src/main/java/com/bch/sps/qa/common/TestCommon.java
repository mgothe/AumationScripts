package com.bch.sps.qa.common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.bch.sps.qa.util.TestUtil;

public class TestCommon { //Start
	
	//Global variable so that we could use through out the project.
	public static WebDriver driver; //had to make public to reflect into LoginPage constructor.
	public static Properties prop;
		
	// this is constructor
	public TestCommon(){
		
	try {
		prop = new Properties();
		//System.out.println(System.getProperty("user.dir"));
		//FileInputStream ip = new FileInputStream("C:\\Users\\mgothe\\workspace\\BCHSPSQA\\src\\main\\java\\com\\bch\\sps\\qa\\config\\config.properties");
		FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+ "/src/main/java/com/bch/sps/qa/config/config.properties");
		prop.load(ip);
		
		} catch (FileNotFoundException e) {
				e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	//initialization method
	public static void initialization(){
		String browserName = prop.getProperty("browser");
		
		if(browserName.equals("chrome")){
			//System.setProperty("webdriver.chrome.driver","C:\\WebAuto\\Browsers\\chromedriver.exe");
			System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+ "/browsers/chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if(browserName.equals("FF")){
			//System.setProperty("webdriver.gecko.driver","C:\\WebAuto\\Browsers\\geckodriver.exe");
			System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir")+ "/browsers/geckodriver.exe");
			driver = new FirefoxDriver();
		}
		else if(browserName.equals("IE")){
			//System.setProperty("webdriver.ie.driver","C:\\WebAuto\\Browsers\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver",System.getProperty("user.dir")+ "/browsers/IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		else{
			System.out.println("Bummber..!!! Broswers not selected !!!");
		}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		//Hard coded timecout
		//driver.manage().timeouts().pageLoadTimeout(20,  TimeUnit.SECONDS);
		//driver.manage().timeouts().implicitlyWait(10,  TimeUnit.SECONDS);
		
		//Not hardcoded, it's from util class. // this can be done through properties file as well.
		driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT,  TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT,  TimeUnit.SECONDS);
		
		//Then launch the URL from reading the properties file.		
		driver.get(prop.getProperty("url"));		
	}
}//End
