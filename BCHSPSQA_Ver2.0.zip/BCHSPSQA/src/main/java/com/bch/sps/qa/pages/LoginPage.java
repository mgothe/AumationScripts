package com.bch.sps.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.bch.sps.qa.common.TestCommon;

//Inherit from TestCommon with extend. 
public class LoginPage extends TestCommon{
	
	//Page Factory - Object Repo:
	@FindBy(name="email")
	WebElement username;
	
	@FindBy(name="password")
	WebElement password;
	
	//Custom xpath
	@FindBy(xpath="/html/body/div[1]/div/div/form/div/div[3]")
	WebElement loginBtn;
	
	public LoginPage(){
		PageFactory.initElements(driver, this);
	}
	
	//Actions:
	public String validateLoginPageTitle(){
		return driver.getTitle();
	}
	
	public HomePage login(String un, String pwd){
		username.sendKeys(un);
		password.sendKeys(pwd);
		loginBtn.click();
		
		return new HomePage();
	}
	

}
