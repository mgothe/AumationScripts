package com.bch.sps.qa.pages;

import org.openqa.selenium.support.PageFactory;

import com.bch.sps.qa.common.TestCommon;

public class HomePage extends TestCommon {
	
	
	//Page Factory - Object Repo:		
			
		public HomePage(){
			PageFactory.initElements(driver, this);
		}
		
		//Actions:
		public String verifyHomePageTitle(){
			return driver.getTitle();
		}	
}

